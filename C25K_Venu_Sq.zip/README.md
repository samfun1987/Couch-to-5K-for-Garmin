# Couch to 5K workouts for Garmin Venu Sq

13 workout files with the NHS Couch to 5K timings. Each one starts with a 5-minute warm-up walk and ends with a 5-minute cool-down walk. The watch moves through every step on its own and buzzes at each change.

| File | Session | Use for |
|---|---|---|
| C25K W1 | 8 × (run 1 min, walk 1½ min) | All 3 runs in week 1 |
| C25K W2 | 6 × (run 1½ min, walk 2 min) | All 3 runs in week 2 |
| C25K W3 | 2 × (run 1½, walk 1½, run 3, walk 3) | All 3 runs in week 3 |
| C25K W4 | run 3, walk 1½, run 5, walk 2½, run 3, walk 1½, run 5 | All 3 runs in week 4 |
| C25K W5 R1 | run 5, walk 3, run 5, walk 3, run 5 | Week 5, run 1 |
| C25K W5 R2 | run 8, walk 5, run 8 | Week 5, run 2 |
| C25K W5 R3 | run 20 | Week 5, run 3 |
| C25K W6 R1 | run 5, walk 3, run 8, walk 3, run 5 | Week 6, run 1 |
| C25K W6 R2 | run 10, walk 3, run 10 | Week 6, run 2 |
| C25K W6 R3 | run 25 | Week 6, run 3 |
| C25K W7 | run 25 | All 3 runs in week 7 |
| C25K W8 | run 28 | All 3 runs in week 8 |
| C25K W9 | run 30 | All 3 runs in week 9 |

## Putting them on the watch (one time, about 5 minutes)

1. Unzip this folder.
2. Plug the Venu Sq into a computer with its charging cable.
3. Open the watch's storage:
   - **Windows:** File Explorer → Venu Sq → Internal Storage → GARMIN → **NewFiles**
   - **Mac:** install the free app OpenMTP (Android File Transfer is unreliable with Garmin), then browse to GARMIN → **NewFiles**
4. Copy all 13 `.fit` files into **NewFiles**. Not the Workouts folder.
5. Eject and unplug. The watch processes the files and they disappear from NewFiles, which is normal.

## On run day

Open the Run activity, go into its options menu, then Training → Workouts, and pick the session (e.g. "C25K W3"). Press start. Don't touch the watch again until the cool-down ends.

## Before your first run

- Check vibration and alert tones are switched on in the watch's sound and vibration settings.
- If the workouts don't show up, restart the watch once.
- These live on the watch only. They won't appear in Garmin Connect's workout list, but your completed runs still sync as normal.
